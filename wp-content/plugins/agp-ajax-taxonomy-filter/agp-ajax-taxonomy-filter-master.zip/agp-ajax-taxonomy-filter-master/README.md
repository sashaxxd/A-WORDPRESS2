# agp-ajax-taxonomy-filter

A plugin for WordPress that let you filter posts by taxonomies with AJAX

# Installation

1. Download a copy of the plugin
2. Unzip and Upload 'AGP Ajax Taxonomy Filter' to a sub directory in '/wp-content/plugins/'.
3. Activate the plugins through the 'Plugins' menu in WordPress.
4. Add 'AGP Ajax Taxonomy Filter' widget to Your sidebar via 'Appearance' > 'Widgets' menu in WordPress.
5. Enjoy!

