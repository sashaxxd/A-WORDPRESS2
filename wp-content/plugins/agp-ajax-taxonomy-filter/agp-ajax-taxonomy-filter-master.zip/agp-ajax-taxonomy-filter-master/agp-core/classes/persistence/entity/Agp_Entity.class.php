<?php

class Agp_Entity extends Agp_EntityAbstract {
}
