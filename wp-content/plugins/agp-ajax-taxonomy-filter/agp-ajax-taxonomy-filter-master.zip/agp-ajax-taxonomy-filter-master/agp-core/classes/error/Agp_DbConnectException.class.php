<?php
class Agp_DbConnectException extends Agp_ExceptionAbstract {
    
}


