    <th>Title</th>
    <th>Description</th>
    <th class="tbl-actions">Actions</th>
